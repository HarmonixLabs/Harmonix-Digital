# Harmony Dashboard - Replit Integration Guide

## Overview

This guide provides step-by-step instructions for integrating the Harmony Dashboard into your Replit environment with full Master Admin capabilities, separate demo accounts, and comprehensive platform control.

## Updated Dashboard Features

### New Components Added
1. **Master Admin Dashboard** - Full platform control and administrative access
2. **What If? AI Support** - ChatGPT-style support interface
3. **Enhanced Super Agency Dashboard** - Multi-tenant agency management
4. **Updated User Profile** - Kwaccar Jok as Super Administrator
5. **Monetization Strategy** - Hybrid pricing model implementation

## Master Admin Dashboard Capabilities

### Core Administrative Functions
- **Agency Management**: Full control over all sub-accounts and agencies
- **System Administration**: Server controls, database management, integrations
- **Customer Support**: Live support queue, issue tracking, quick actions
- **Billing Management**: Revenue oversight, payment processing, token economy
- **Security Controls**: Access management, security monitoring, audit logs
- **Troubleshooting Tools**: Bug fixes, system updates, performance monitoring

### Separation from Demo Accounts
- **Production Environment**: Full feature access for paid accounts
- **Demo Environment**: Limited functionality for testing and lead generation
- **Access Controls**: Role-based permissions with Super Admin override
- **Data Isolation**: Separate databases for demo vs production accounts

## Replit Implementation Steps

### 1. Project Setup

```bash
# Clone the dashboard code into your Replit project
git clone <your-harmony-dashboard-repo>
cd harmony-dashboard

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
```

### 2. Environment Configuration

Create `.env` file with the following variables:

```env
# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/harmony_db
DEMO_DATABASE_URL=postgresql://username:password@localhost:5432/harmony_demo_db

# Authentication
JWT_SECRET=your-super-secret-jwt-key
ADMIN_EMAIL=kwaccar@harmonix.com
ADMIN_PASSWORD=your-secure-admin-password

# API Keys
OPENAI_API_KEY=your-openai-api-key
STRIPE_SECRET_KEY=your-stripe-secret-key
STRIPE_WEBHOOK_SECRET=your-stripe-webhook-secret

# Integration APIs
GOHIGHLEVEL_API_KEY=your-ghl-api-key
HUBSPOT_API_KEY=your-hubspot-api-key
SALESFORCE_API_KEY=your-salesforce-api-key

# Token Economy
HRMNY_TOKEN_CONTRACT=your-token-contract-address
WALLET_PRIVATE_KEY=your-wallet-private-key

# System Configuration
NODE_ENV=production
PORT=3000
FRONTEND_URL=https://your-replit-app.repl.co
```

### 3. Database Schema

```sql
-- Users table with role-based access
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'user', -- 'super_admin', 'admin', 'user', 'demo'
  agency_id INTEGER REFERENCES agencies(id),
  is_demo BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Agencies table for multi-tenant support
CREATE TABLE agencies (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  owner_id INTEGER REFERENCES users(id),
  plan VARCHAR(50) NOT NULL, -- 'starter', 'professional', 'enterprise'
  status VARCHAR(50) DEFAULT 'active',
  monthly_revenue DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Agents table
CREATE TABLE agents (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(100) NOT NULL,
  agency_id INTEGER REFERENCES agencies(id),
  status VARCHAR(50) DEFAULT 'inactive',
  configuration JSONB,
  performance_metrics JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Support tickets table
CREATE TABLE support_tickets (
  id SERIAL PRIMARY KEY,
  agency_id INTEGER REFERENCES agencies(id),
  user_id INTEGER REFERENCES users(id),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  severity VARCHAR(50) DEFAULT 'medium',
  status VARCHAR(50) DEFAULT 'open',
  assigned_to INTEGER REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Billing table
CREATE TABLE billing (
  id SERIAL PRIMARY KEY,
  agency_id INTEGER REFERENCES agencies(id),
  amount DECIMAL(10,2) NOT NULL,
  type VARCHAR(50) NOT NULL, -- 'subscription', 'setup', 'nft', 'token'
  status VARCHAR(50) DEFAULT 'pending',
  stripe_payment_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- System logs table
CREATE TABLE system_logs (
  id SERIAL PRIMARY KEY,
  level VARCHAR(50) NOT NULL,
  message TEXT NOT NULL,
  user_id INTEGER REFERENCES users(id),
  agency_id INTEGER REFERENCES agencies(id),
  metadata JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 4. Backend API Implementation

Create the following API endpoints:

#### Authentication Routes
```javascript
// routes/auth.js
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const router = express.Router();

// Super Admin login
router.post('/admin/login', async (req, res) => {
  const { email, password } = req.body;
  
  // Verify super admin credentials
  if (email === process.env.ADMIN_EMAIL) {
    const isValid = await bcrypt.compare(password, adminPasswordHash);
    if (isValid) {
      const token = jwt.sign(
        { userId: 'super_admin', role: 'super_admin' },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
      );
      res.json({ token, role: 'super_admin' });
    }
  }
  
  res.status(401).json({ error: 'Invalid credentials' });
});

// Demo account creation
router.post('/demo/signup', async (req, res) => {
  // Create limited demo account
  const demoUser = await createDemoUser(req.body);
  res.json({ user: demoUser, isDemo: true });
});
```

#### Master Admin Routes
```javascript
// routes/admin.js
const express = require('express');
const router = express.Router();

// Middleware to verify super admin access
const requireSuperAdmin = (req, res, next) => {
  if (req.user.role !== 'super_admin') {
    return res.status(403).json({ error: 'Super admin access required' });
  }
  next();
};

// Get all agencies
router.get('/agencies', requireSuperAdmin, async (req, res) => {
  const agencies = await Agency.findAll({
    include: [User, Agent, SupportTicket]
  });
  res.json(agencies);
});

// Access agency dashboard
router.post('/agencies/:id/access', requireSuperAdmin, async (req, res) => {
  const agency = await Agency.findByPk(req.params.id);
  const accessToken = generateAgencyAccessToken(agency.id);
  res.json({ accessToken, dashboardUrl: `/agency/${agency.id}` });
});

// System health check
router.get('/system/health', requireSuperAdmin, async (req, res) => {
  const health = await getSystemHealth();
  res.json(health);
});

// Force agent restart
router.post('/agents/:id/restart', requireSuperAdmin, async (req, res) => {
  await restartAgent(req.params.id);
  res.json({ success: true });
});
```

### 5. Frontend Integration

Update your Replit main.py or app.js:

```python
# main.py (if using Python/Flask)
from flask import Flask, render_template, send_from_directory
import os

app = Flask(__name__, static_folder='harmony-dashboard/dist')

@app.route('/')
def index():
    return send_from_directory('harmony-dashboard/dist', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('harmony-dashboard/dist', path)

# API routes
@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    # Implement admin authentication
    pass

@app.route('/api/agencies', methods=['GET'])
def get_agencies():
    # Implement agency management
    pass

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)
```

### 6. Security Implementation

```javascript
// middleware/security.js
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');

// Rate limiting for admin endpoints
const adminLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many admin requests from this IP'
});

// Security headers
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

// Admin route protection
app.use('/api/admin', adminLimiter);
```

### 7. Demo vs Production Separation

```javascript
// middleware/demoCheck.js
const checkDemoAccess = (req, res, next) => {
  if (req.user.is_demo) {
    // Restrict demo users to limited features
    const allowedRoutes = [
      '/api/agents/demo',
      '/api/dashboard/demo',
      '/api/marketplace/browse'
    ];
    
    if (!allowedRoutes.includes(req.path)) {
      return res.status(403).json({ 
        error: 'Feature not available in demo mode',
        upgradeRequired: true 
      });
    }
  }
  next();
};
```

### 8. Deployment Configuration

```yaml
# replit.nix
{ pkgs }: {
  deps = [
    pkgs.nodejs-18_x
    pkgs.postgresql
    pkgs.redis
  ];
}
```

```bash
# .replit
run = "npm start"
entrypoint = "server.js"

[env]
NODE_ENV = "production"

[nix]
channel = "stable-22_11"

[deployment]
run = ["sh", "-c", "npm start"]
```

## Master Admin Login Credentials

### Super Administrator Access
- **Email**: kwaccar@harmonix.com
- **Password**: [Set secure password in environment]
- **Role**: super_admin
- **Permissions**: Full platform access

### Demo Account Limitations
- **Agent Limit**: 3 agents maximum
- **Feature Access**: Basic functionality only
- **Time Limit**: 7-day trial period
- **Integrations**: None available
- **Support**: Community support only

## Monetization Integration

### Pricing Tiers Implementation
```javascript
// config/pricing.js
const PRICING_TIERS = {
  demo: {
    price: 0,
    agents: 3,
    features: ['basic_dashboard', 'limited_agents'],
    duration: 7 // days
  },
  starter: {
    price: 97,
    agents: 3,
    features: ['full_dashboard', 'basic_integrations'],
    setup_fee: 0
  },
  professional: {
    price: 297,
    agents: 6,
    features: ['super_agency', 'advanced_integrations', 'white_label'],
    setup_fee: 500
  },
  enterprise: {
    price: 'custom',
    agents: 'unlimited',
    features: ['everything', 'custom_development'],
    setup_fee: 'custom'
  }
};
```

## Testing Checklist

- [ ] Master Admin Dashboard loads correctly
- [ ] Super admin can access all agencies
- [ ] Demo accounts have limited functionality
- [ ] Production accounts have full access
- [ ] Billing integration works
- [ ] Support ticket system functions
- [ ] System health monitoring active
- [ ] Security controls implemented
- [ ] API endpoints secured
- [ ] Database separation working

## Support and Maintenance

### Regular Tasks
1. **Daily**: Monitor system health and support queue
2. **Weekly**: Review agency performance and billing
3. **Monthly**: Update security patches and features
4. **Quarterly**: Analyze platform metrics and optimization

### Emergency Procedures
1. **System Down**: Use Master Admin to restart services
2. **Security Breach**: Immediately revoke access tokens
3. **Payment Issues**: Access billing dashboard for resolution
4. **Agent Failures**: Use quick restart tools in Master Admin

## Conclusion

This implementation provides a complete separation between demo and production environments while giving you full administrative control over the entire platform. The Master Admin Dashboard serves as your command center for managing all aspects of the Harmony ecosystem.

For additional support or custom modifications, refer to the technical documentation or contact the development team.

