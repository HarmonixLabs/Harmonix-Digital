import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { 
  Search, 
  Star, 
  Play, 
  ShoppingCart,
  Filter,
  TrendingUp,
  Users,
  Zap
} from 'lucide-react'

const categories = [
  'Sales & Marketing',
  'Customer Support',
  'Content Creation',
  'Data Analysis',
  'Operations',
  'Finance',
  'HR & Recruiting'
]

const agents = [
  {
    id: 1,
    name: 'Sales Automation Pro',
    creator: 'TechCorp Solutions',
    description: 'Advanced sales automation agent that handles lead qualification, follow-ups, and deal closing.',
    price: 49.99,
    rating: 4.8,
    reviews: 234,
    category: 'Sales & Marketing',
    features: ['Lead Qualification', 'Email Automation', 'CRM Integration'],
    avatar: '🚀',
    featured: true
  },
  {
    id: 2,
    name: 'Content Creator AI',
    creator: 'Creative Minds',
    description: 'Generate high-quality blog posts, social media content, and marketing copy automatically.',
    price: 29.99,
    rating: 4.6,
    reviews: 156,
    category: 'Content Creation',
    features: ['Blog Writing', 'Social Media', 'SEO Optimization'],
    avatar: '✍️',
    featured: true
  },
  {
    id: 3,
    name: 'Customer Support Bot',
    creator: 'Support Solutions',
    description: 'Intelligent customer support agent that handles inquiries, tickets, and escalations.',
    price: 39.99,
    rating: 4.9,
    reviews: 312,
    category: 'Customer Support',
    features: ['24/7 Support', 'Multi-language', 'Ticket Management'],
    avatar: '💬',
    featured: false
  },
  {
    id: 4,
    name: 'Data Analytics Engine',
    creator: 'DataPro Inc',
    description: 'Powerful data analysis agent that generates insights, reports, and visualizations.',
    price: 79.99,
    rating: 4.7,
    reviews: 89,
    category: 'Data Analysis',
    features: ['Real-time Analytics', 'Custom Reports', 'Predictive Modeling'],
    avatar: '📊',
    featured: false
  },
  {
    id: 5,
    name: 'Social Media Manager',
    creator: 'Social Boost',
    description: 'Automate your social media presence with intelligent posting and engagement.',
    price: 24.99,
    rating: 4.5,
    reviews: 178,
    category: 'Sales & Marketing',
    features: ['Auto Posting', 'Engagement', 'Analytics'],
    avatar: '📱',
    featured: true
  },
  {
    id: 6,
    name: 'HR Recruitment Assistant',
    creator: 'TalentFinder',
    description: 'Streamline your hiring process with automated candidate screening and scheduling.',
    price: 59.99,
    rating: 4.4,
    reviews: 67,
    category: 'HR & Recruiting',
    features: ['Resume Screening', 'Interview Scheduling', 'Candidate Tracking'],
    avatar: '👥',
    featured: false
  }
]

export function Marketplace() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategories, setSelectedCategories] = useState([])
  const [priceRange, setPriceRange] = useState([0, 100])
  const [showFilters, setShowFilters] = useState(false)

  const filteredAgents = agents.filter(agent => {
    const matchesSearch = agent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         agent.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(agent.category)
    const matchesPrice = agent.price >= priceRange[0] && agent.price <= priceRange[1]
    
    return matchesSearch && matchesCategory && matchesPrice
  })

  const featuredAgents = agents.filter(agent => agent.featured)

  const handleCategoryChange = (category, checked) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, category])
    } else {
      setSelectedCategories(selectedCategories.filter(c => c !== category))
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Agent Marketplace</h1>
        <Button variant="outline">
          <TrendingUp className="h-4 w-4 mr-2" />
          Trending
        </Button>
      </div>

      {/* Featured Agents */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Featured Agents</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredAgents.slice(0, 3).map((agent) => (
            <Card key={agent.id} className="relative overflow-hidden">
              <div className="absolute top-2 right-2">
                <Badge className="bg-yellow-100 text-yellow-800">Featured</Badge>
              </div>
              <CardHeader className="pb-3">
                <div className="flex items-center space-x-3">
                  <div className="text-3xl">{agent.avatar}</div>
                  <div>
                    <CardTitle className="text-lg">{agent.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">by {agent.creator}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">{agent.description}</p>
                <div className="flex items-center space-x-2 mb-3">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium ml-1">{agent.rating}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">({agent.reviews} reviews)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold">${agent.price}</span>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      <Play className="h-4 w-4" />
                    </Button>
                    <Button size="sm">
                      <ShoppingCart className="h-4 w-4 mr-1" />
                      Buy
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex items-center space-x-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            type="text"
            placeholder="Search agents..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button
          variant="outline"
          onClick={() => setShowFilters(!showFilters)}
        >
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </Button>
      </div>

      <div className="flex gap-6">
        {/* Filters Sidebar */}
        {showFilters && (
          <div className="w-64 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Categories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {categories.map((category) => (
                  <div key={category} className="flex items-center space-x-2">
                    <Checkbox
                      id={category}
                      checked={selectedCategories.includes(category)}
                      onCheckedChange={(checked) => handleCategoryChange(category, checked)}
                    />
                    <label htmlFor={category} className="text-sm">{category}</label>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Price Range</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">$0</span>
                    <span className="text-sm">$100+</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([0, parseInt(e.target.value)])}
                    className="w-full"
                  />
                  <p className="text-sm text-muted-foreground">
                    Up to ${priceRange[1]}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Agent Grid */}
        <div className="flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAgents.map((agent) => (
              <Card key={agent.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center space-x-3">
                    <div className="text-2xl">{agent.avatar}</div>
                    <div>
                      <CardTitle className="text-lg">{agent.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">by {agent.creator}</p>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{agent.description}</p>
                  
                  <div className="flex flex-wrap gap-1">
                    {agent.features.map((feature, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center space-x-2">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium ml-1">{agent.rating}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">({agent.reviews})</span>
                    <Badge variant="outline">{agent.category}</Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xl font-bold">${agent.price}</span>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline">
                        <Play className="h-4 w-4" />
                      </Button>
                      <Button size="sm">
                        <ShoppingCart className="h-4 w-4 mr-1" />
                        Buy
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

