import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Wallet as WalletIcon, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft,
  CreditCard,
  Bitcoin,
  Building,
  TrendingUp,
  Shield,
  Clock
} from 'lucide-react'

const transactions = [
  {
    id: 1,
    type: 'recharge',
    amount: 1250,
    usd: 100,
    status: 'completed',
    date: '2024-01-15',
    method: 'Stripe'
  },
  {
    id: 2,
    type: 'fuel',
    amount: -500,
    usd: -40,
    status: 'completed',
    date: '2024-01-14',
    method: 'Agent Fuel'
  },
  {
    id: 3,
    type: 'stake',
    amount: -1200,
    usd: -96,
    status: 'pending',
    date: '2024-01-13',
    method: 'Staking'
  },
  {
    id: 4,
    type: 'reward',
    amount: 75,
    usd: 6,
    status: 'completed',
    date: '2024-01-12',
    method: 'Staking Reward'
  }
]

export function Wallet() {
  const [rechargeAmount, setRechargeAmount] = useState(100)
  const [paymentMethod, setPaymentMethod] = useState('stripe')

  const getTransactionIcon = (type) => {
    switch (type) {
      case 'recharge':
      case 'reward':
        return <ArrowDownLeft className="h-4 w-4 text-green-600" />
      case 'fuel':
      case 'stake':
        return <ArrowUpRight className="h-4 w-4 text-red-600" />
      default:
        return <WalletIcon className="h-4 w-4" />
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
      case 'failed':
        return <Badge className="bg-red-100 text-red-800">Failed</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  const presetAmounts = [50, 100, 250, 500]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Wallet & Billing</h1>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Recharge HRMNY
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Recharge HRMNY Tokens</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <Tabs value={paymentMethod} onValueChange={setPaymentMethod}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="stripe" className="flex items-center space-x-2">
                    <CreditCard className="h-4 w-4" />
                    <span>Stripe</span>
                  </TabsTrigger>
                  <TabsTrigger value="crypto" className="flex items-center space-x-2">
                    <Bitcoin className="h-4 w-4" />
                    <span>Crypto</span>
                  </TabsTrigger>
                  <TabsTrigger value="bank" className="flex items-center space-x-2">
                    <Building className="h-4 w-4" />
                    <span>Bank</span>
                  </TabsTrigger>
                </TabsList>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="amount">Amount (USD)</Label>
                    <div className="grid grid-cols-4 gap-2 mt-2">
                      {presetAmounts.map((amount) => (
                        <Button
                          key={amount}
                          variant={rechargeAmount === amount ? "default" : "outline"}
                          size="sm"
                          onClick={() => setRechargeAmount(amount)}
                        >
                          ${amount}
                        </Button>
                      ))}
                    </div>
                    <Input
                      id="amount"
                      type="number"
                      value={rechargeAmount}
                      onChange={(e) => setRechargeAmount(Number(e.target.value))}
                      className="mt-2"
                      placeholder="Custom amount"
                    />
                  </div>

                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex justify-between text-sm">
                      <span>HRMNY Tokens:</span>
                      <span className="font-medium">{rechargeAmount * 12.5}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Bonus Tokens:</span>
                      <span className="font-medium text-green-600">+{Math.floor(rechargeAmount * 1.25)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Processing Fee:</span>
                      <span className="font-medium">${(rechargeAmount * 0.03).toFixed(2)}</span>
                    </div>
                    <hr className="my-2" />
                    <div className="flex justify-between font-medium">
                      <span>Total:</span>
                      <span>${(rechargeAmount + rechargeAmount * 0.03).toFixed(2)}</span>
                    </div>
                  </div>

                  <TabsContent value="stripe" className="space-y-3">
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" placeholder="your@email.com" />
                    </div>
                    <div>
                      <Label htmlFor="card">Card Information</Label>
                      <Input id="card" placeholder="4242 4242 4242 4242" />
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <Input placeholder="MM/YY" />
                        <Input placeholder="CVC" />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="crypto" className="space-y-3">
                    <div className="text-center p-4 border-2 border-dashed border-gray-300 rounded-lg">
                      <Bitcoin className="h-8 w-8 mx-auto mb-2 text-orange-500" />
                      <p className="text-sm text-muted-foreground">
                        Send payment to the address that will be generated after clicking "Complete Recharge"
                      </p>
                    </div>
                  </TabsContent>

                  <TabsContent value="bank" className="space-y-3">
                    <div className="text-center p-4 border-2 border-dashed border-gray-300 rounded-lg">
                      <Building className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                      <p className="text-sm text-muted-foreground">
                        Bank transfer details will be provided after clicking "Complete Recharge"
                      </p>
                    </div>
                  </TabsContent>

                  <Button className="w-full">
                    Complete Recharge
                  </Button>
                </div>
              </Tabs>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Balance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <WalletIcon className="h-5 w-5" />
              <span>HRMNY Balance</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="text-4xl font-bold">12,560 HRMNY</div>
                <div className="text-lg text-muted-foreground">≈ $1,004.80 USD</div>
              </div>
              <div className="flex space-x-4">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="h-4 w-4 mr-2" />
                      Recharge
                    </Button>
                  </DialogTrigger>
                </Dialog>
                <Button variant="outline">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Stake
                </Button>
                <Button variant="outline">
                  <ArrowUpRight className="h-4 w-4 mr-2" />
                  Transfer
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Staking Rewards</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="text-2xl font-bold">2,400 HRMNY</div>
                <div className="text-sm text-muted-foreground">Staked Amount</div>
              </div>
              <div>
                <div className="text-lg font-bold text-green-600">+75 HRMNY</div>
                <div className="text-sm text-muted-foreground">This Month's Rewards</div>
              </div>
              <div className="text-sm">
                <div className="flex justify-between">
                  <span>APY:</span>
                  <span className="font-medium">8.5%</span>
                </div>
                <div className="flex justify-between">
                  <span>Lock Period:</span>
                  <span className="font-medium">30 days</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Subscription and Usage */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Current Subscription</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Pro Plan</h3>
                  <p className="text-sm text-muted-foreground">Up to 10 agents</p>
                </div>
                <Badge>Active</Badge>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Agents Used:</span>
                  <span>4 / 10</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-indigo-600 h-2 rounded-full" style={{ width: '40%' }} />
                </div>
              </div>
              <div className="flex justify-between text-sm">
                <span>Next Billing:</span>
                <span>Jan 15, 2024</span>
              </div>
              <Button variant="outline" className="w-full">
                Manage Subscription
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Security</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Shield className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Two-Factor Authentication</span>
                </div>
                <Badge className="bg-green-100 text-green-800">Enabled</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">Session Timeout</span>
                </div>
                <span className="text-sm text-muted-foreground">24 hours</span>
              </div>
              <Button variant="outline" className="w-full">
                Security Settings
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Transaction History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  {getTransactionIcon(transaction.type)}
                  <div>
                    <p className="font-medium capitalize">{transaction.type}</p>
                    <p className="text-sm text-muted-foreground">{transaction.method}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className={`font-medium ${transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {transaction.amount > 0 ? '+' : ''}{transaction.amount} HRMNY
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {transaction.usd > 0 ? '+' : ''}${Math.abs(transaction.usd)}
                    </p>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(transaction.status)}
                    <p className="text-sm text-muted-foreground mt-1">{transaction.date}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

