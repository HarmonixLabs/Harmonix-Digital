import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Building2,
  Users,
  Bot,
  DollarSign,
  TrendingUp,
  Eye,
  Settings,
  MoreHorizontal,
  Search,
  Filter
} from 'lucide-react'

const agencies = [
  {
    id: 1,
    name: 'TechFlow Agency',
    owner: 'Sarah Johnson',
    users: 25,
    agents: 8,
    monthlyRevenue: 15000,
    status: 'active',
    plan: 'Enterprise'
  },
  {
    id: 2,
    name: 'Digital Creators Hub',
    owner: 'Mike Chen',
    users: 12,
    agents: 6,
    monthlyRevenue: 8500,
    status: 'active',
    plan: 'Professional'
  },
  {
    id: 3,
    name: 'E-commerce Solutions',
    owner: 'Lisa Rodriguez',
    users: 18,
    agents: 10,
    monthlyRevenue: 22000,
    status: 'active',
    plan: 'Enterprise'
  }
]

export function SuperAgencyDashboard() {
  const [searchTerm, setSearchTerm] = useState('')

  const filteredAgencies = agencies.filter(agency =>
    agency.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    agency.owner.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const totalRevenue = agencies.reduce((sum, agency) => sum + agency.monthlyRevenue, 0)
  const totalUsers = agencies.reduce((sum, agency) => sum + agency.users, 0)
  const totalAgents = agencies.reduce((sum, agency) => sum + agency.agents, 0)

  return (
    <div className="space-y-6">
      {/* Super Agency Header */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">Super Agency Dashboard</h1>
        <p className="text-purple-100 mb-4">Master control center for all agencies and sub-accounts</p>
        <div className="flex space-x-4">
          <Button variant="secondary" className="bg-white text-purple-600 hover:bg-gray-100">
            <Building2 className="h-4 w-4 mr-2" />
            Add New Agency
          </Button>
          <Button variant="outline" className="border-white text-white hover:bg-white hover:text-purple-600">
            <Settings className="h-4 w-4 mr-2" />
            Platform Settings
          </Button>
        </div>
      </div>

      {/* Platform Overview Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Agencies</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{agencies.length}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+3</span> this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalUsers}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+45</span> this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Agents</CardTitle>
            <Bot className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalAgents}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+12</span> this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+18%</span> from last month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Agency Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Agency Management</span>
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search agencies..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredAgencies.map((agency) => (
              <Card key={agency.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                        {agency.name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">{agency.name}</h3>
                        <p className="text-sm text-gray-600">Owner: {agency.owner}</p>
                        <div className="flex items-center space-x-4 mt-1">
                          <Badge variant={agency.status === 'active' ? 'default' : 'secondary'}>
                            {agency.status}
                          </Badge>
                          <Badge variant="outline">{agency.plan}</Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-6">
                      <div className="text-center">
                        <div className="text-lg font-bold">{agency.users}</div>
                        <div className="text-xs text-gray-500">Users</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold">{agency.agents}</div>
                        <div className="text-xs text-gray-500">Agents</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-green-600">${agency.monthlyRevenue.toLocaleString()}</div>
                        <div className="text-xs text-gray-500">Monthly Revenue</div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Settings className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

