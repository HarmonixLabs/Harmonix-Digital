import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { MessageSquare, Send, Bot, User } from 'lucide-react'

export function WhatIf() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'bot',
      content: "Hi! I'm your Harmony AI assistant. I can help you with questions about your agents, platform features, troubleshooting, and more. What would you like to know?"
    }
  ])
  const [inputMessage, setInputMessage] = useState('')

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return

    const newUserMessage = {
      id: messages.length + 1,
      type: 'user',
      content: inputMessage
    }

    const botResponse = {
      id: messages.length + 2,
      type: 'bot',
      content: generateBotResponse(inputMessage)
    }

    setMessages([...messages, newUserMessage, botResponse])
    setInputMessage('')
  }

  const generateBotResponse = (userMessage) => {
    const lowerMessage = userMessage.toLowerCase()
    
    if (lowerMessage.includes('agent') && lowerMessage.includes('deploy')) {
      return "To deploy an agent, go to the Marketplace, select the agent you want, and click 'Deploy Agent'. You'll need sufficient HRMNY tokens in your wallet. Would you like me to guide you through the specific steps?"
    }
    
    if (lowerMessage.includes('balance') || lowerMessage.includes('wallet')) {
      return "Your current HRMNY balance is 2,100,000 tokens. You can recharge your wallet by connecting a credit card or crypto wallet in the Wallet section. Need help with payment methods?"
    }
    
    if (lowerMessage.includes('commission') || lowerMessage.includes('earning')) {
      return "Your total commissions earned are $1,500.00. Commissions are calculated based on agent usage and performance. You can view detailed earnings in the Creator Zone under the Earnings tab."
    }
    
    if (lowerMessage.includes('agency') || lowerMessage.includes('sub-account')) {
      return "As a Super Admin, you can manage all agencies through the Super Agency Dashboard. You can view agency performance, manage users, and monitor revenue across all sub-accounts. Would you like help with a specific agency management task?"
    }
    
    if (lowerMessage.includes('marketplace') || lowerMessage.includes('buy')) {
      return "The Marketplace has 14 specialized agents available, including Cash (Sales), Echo (Content), Flow (Operations), and more. Each agent has different pricing and NFT editions. What type of agent are you looking for?"
    }
    
    return "I understand you're asking about: " + userMessage + ". Could you provide more specific details so I can give you a more targeted answer? I can help with agent deployment, wallet management, earnings, marketplace navigation, and platform features."
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">What If? - AI Support</h1>
        <Button variant="outline">
          <MessageSquare className="h-4 w-4 mr-2" />
          Clear Chat
        </Button>
      </div>

      <Card className="h-[600px] flex flex-col">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bot className="h-6 w-6 text-blue-500" />
            <span>Harmony AI Assistant</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto space-y-4 mb-4 p-4 bg-gray-50 rounded-lg">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.type === 'user'
                      ? 'bg-blue-500 text-white'
                      : 'bg-white border shadow-sm'
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    {message.type === 'bot' && <Bot className="h-4 w-4 mt-1 text-blue-500" />}
                    {message.type === 'user' && <User className="h-4 w-4 mt-1" />}
                    <p className="text-sm">{message.content}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Input Area */}
          <div className="flex space-x-2">
            <Input
              type="text"
              placeholder="Ask me anything about Harmony..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-1"
            />
            <Button onClick={handleSendMessage}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Help Topics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Button 
              variant="outline" 
              className="h-auto p-4 text-left"
              onClick={() => setInputMessage("How do I deploy an agent?")}
            >
              <div>
                <div className="font-medium">Deploy Agents</div>
                <div className="text-sm text-gray-500">Learn how to deploy and manage agents</div>
              </div>
            </Button>
            <Button 
              variant="outline" 
              className="h-auto p-4 text-left"
              onClick={() => setInputMessage("How do I check my wallet balance?")}
            >
              <div>
                <div className="font-medium">Wallet & Payments</div>
                <div className="text-sm text-gray-500">Manage your HRMNY tokens and payments</div>
              </div>
            </Button>
            <Button 
              variant="outline" 
              className="h-auto p-4 text-left"
              onClick={() => setInputMessage("How do commissions work?")}
            >
              <div>
                <div className="font-medium">Earnings & Commissions</div>
                <div className="text-sm text-gray-500">Understand your revenue streams</div>
              </div>
            </Button>
            <Button 
              variant="outline" 
              className="h-auto p-4 text-left"
              onClick={() => setInputMessage("How do I manage agencies?")}
            >
              <div>
                <div className="font-medium">Agency Management</div>
                <div className="text-sm text-gray-500">Control sub-accounts and agencies</div>
              </div>
            </Button>
            <Button 
              variant="outline" 
              className="h-auto p-4 text-left"
              onClick={() => setInputMessage("What agents are available in the marketplace?")}
            >
              <div>
                <div className="font-medium">Marketplace</div>
                <div className="text-sm text-gray-500">Browse and purchase agents</div>
              </div>
            </Button>
            <Button 
              variant="outline" 
              className="h-auto p-4 text-left"
              onClick={() => setInputMessage("How do I create my own agent?")}
            >
              <div>
                <div className="font-medium">Creator Zone</div>
                <div className="text-sm text-gray-500">Build and monetize custom agents</div>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

