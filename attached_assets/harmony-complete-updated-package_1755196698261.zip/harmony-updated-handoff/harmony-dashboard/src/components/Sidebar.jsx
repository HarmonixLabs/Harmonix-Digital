import { Link, useLocation } from 'react-router-dom'
import { 
  Home, 
  Bot, 
  Store, 
  Wrench, 
  Wallet, 
  Settings, 
  ChevronLeft,
  ChevronRight,
  MessageSquare,
  Shield
} from 'lucide-react'
import { Button } from '@/components/ui/button'

const navigation = [
  { name: 'Dashboard', href: '/', icon: Home },
  { name: 'My Agents', href: '/my-agents', icon: Bot },
  { name: 'Marketplace', href: '/marketplace', icon: Store },
  { name: 'Creator Zone', href: '/creator-zone', icon: Wrench },
  { name: 'Wallet', href: '/wallet', icon: Wallet },
  { name: 'Settings', href: '/settings', icon: Settings },
  { name: 'What If?', href: '/what-if', icon: MessageSquare },
  { name: 'Master Admin', href: '/master-admin', icon: Shield },
]

export function Sidebar({ collapsed, onToggle }) {
  const location = useLocation()

  return (
    <div className={`bg-gray-900 text-white transition-all duration-300 ${collapsed ? 'w-16' : 'w-64'}`}>
      <div className="flex items-center justify-between p-4">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">H</span>
            </div>
            <span className="text-xl font-bold">Harmony</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggle}
          className="text-gray-400 hover:text-white hover:bg-gray-800"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      <nav className="mt-8">
        <div className="px-2 space-y-1">
          {navigation.map((item) => {
            const isActive = location.pathname === item.href
            const Icon = item.icon
            
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ${
                  isActive
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                }`}
              >
                <Icon className={`flex-shrink-0 h-5 w-5 ${collapsed ? 'mx-auto' : 'mr-3'}`} />
                {!collapsed && item.name}
              </Link>
            )
          })}
        </div>
      </nav>

      {!collapsed && (
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-800">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-red-600 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-white">KJ</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">Kwaccar Jok</p>
              <p className="text-xs text-gray-400 truncate">Super Admin</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

