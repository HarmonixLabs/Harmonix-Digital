import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Shield,
  Users,
  Bot,
  DollarSign,
  Settings,
  Bug,
  Wrench,
  CreditCard,
  MessageSquare,
  Database,
  Lock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Search,
  Filter,
  Download,
  Upload,
  RefreshCw,
  Terminal,
  Eye,
  Edit,
  Trash2
} from 'lucide-react'

const systemHealth = {
  status: 'healthy',
  uptime: '99.97%',
  activeUsers: 1247,
  totalAgents: 15680,
  apiCalls: 2847392,
  errorRate: '0.03%'
}

const recentIssues = [
  {
    id: 1,
    type: 'bug',
    severity: 'high',
    title: 'Agent deployment timeout in EU region',
    agency: 'TechFlow Agency',
    status: 'investigating',
    reportedAt: '2 hours ago'
  },
  {
    id: 2,
    type: 'billing',
    severity: 'medium',
    title: 'Payment processing delay for Enterprise accounts',
    agency: 'Multiple',
    status: 'resolved',
    reportedAt: '4 hours ago'
  },
  {
    id: 3,
    type: 'integration',
    severity: 'low',
    title: 'GoHighLevel sync intermittent failures',
    agency: 'Digital Creators Hub',
    status: 'monitoring',
    reportedAt: '6 hours ago'
  }
]

const agencies = [
  {
    id: 1,
    name: 'TechFlow Agency',
    owner: 'Sarah Johnson',
    plan: 'Enterprise',
    status: 'active',
    users: 25,
    agents: 8,
    monthlyRevenue: 15000,
    lastLogin: '2 hours ago',
    issues: 1
  },
  {
    id: 2,
    name: 'Digital Creators Hub',
    owner: 'Mike Chen',
    plan: 'Professional',
    status: 'active',
    users: 12,
    agents: 6,
    monthlyRevenue: 8500,
    lastLogin: '30 minutes ago',
    issues: 0
  },
  {
    id: 3,
    name: 'E-commerce Solutions',
    owner: 'Lisa Rodriguez',
    plan: 'Enterprise',
    status: 'active',
    users: 18,
    agents: 10,
    monthlyRevenue: 22000,
    lastLogin: '1 hour ago',
    issues: 0
  }
]

export function MasterAdminDashboard() {
  const [selectedAgency, setSelectedAgency] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [activeTab, setActiveTab] = useState('overview')

  return (
    <div className="space-y-6">
      {/* Master Admin Header */}
      <div className="bg-gradient-to-r from-red-600 to-purple-700 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Master Admin Dashboard</h1>
            <p className="text-red-100 mb-4">Full platform control and administrative access</p>
            <div className="flex items-center space-x-4">
              <Badge className="bg-green-500 text-white">
                <CheckCircle className="h-3 w-3 mr-1" />
                System Healthy
              </Badge>
              <Badge className="bg-blue-500 text-white">
                Uptime: {systemHealth.uptime}
              </Badge>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-red-100">Logged in as</div>
            <div className="text-xl font-bold">Kwaccar Jok</div>
            <div className="text-sm text-red-100">Super Administrator</div>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="agencies">Agencies</TabsTrigger>
          <TabsTrigger value="support">Support</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          {/* System Health Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{systemHealth.activeUsers.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">+12%</span> from last hour
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Agents</CardTitle>
                <Bot className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{systemHealth.totalAgents.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">+156</span> deployed today
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">API Calls</CardTitle>
                <Database className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{systemHealth.apiCalls.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">+8%</span> from yesterday
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Error Rate</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{systemHealth.errorRate}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">-0.01%</span> from last week
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Recent Issues */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bug className="h-6 w-6 text-red-500" />
                <span>Recent Issues & Support Tickets</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentIssues.map((issue) => (
                  <div key={issue.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className={`w-3 h-3 rounded-full ${
                        issue.severity === 'high' ? 'bg-red-500' :
                        issue.severity === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                      }`}></div>
                      <div>
                        <h3 className="font-medium">{issue.title}</h3>
                        <p className="text-sm text-gray-600">{issue.agency} • {issue.reportedAt}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={issue.status === 'resolved' ? 'default' : 'secondary'}>
                        {issue.status}
                      </Badge>
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="agencies">
          {/* Agency Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Agency Management & Control</span>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      type="text"
                      placeholder="Search agencies..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Button variant="outline" size="sm">
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {agencies.map((agency) => (
                  <Card key={agency.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                            {agency.name.charAt(0)}
                          </div>
                          <div>
                            <h3 className="font-bold text-lg">{agency.name}</h3>
                            <p className="text-sm text-gray-600">Owner: {agency.owner}</p>
                            <div className="flex items-center space-x-4 mt-1">
                              <Badge variant={agency.status === 'active' ? 'default' : 'secondary'}>
                                {agency.status}
                              </Badge>
                              <Badge variant="outline">{agency.plan}</Badge>
                              {agency.issues > 0 && (
                                <Badge variant="destructive">{agency.issues} issues</Badge>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-6">
                          <div className="text-center">
                            <div className="text-lg font-bold">{agency.users}</div>
                            <div className="text-xs text-gray-500">Users</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold">{agency.agents}</div>
                            <div className="text-xs text-gray-500">Agents</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold text-green-600">${agency.monthlyRevenue.toLocaleString()}</div>
                            <div className="text-xs text-gray-500">Monthly Revenue</div>
                          </div>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm" title="Access Dashboard">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm" title="Edit Settings">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm" title="System Tools">
                              <Wrench className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm" title="Support">
                              <MessageSquare className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="support">
          {/* Customer Support Tools */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Live Support Queue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <div>
                      <div className="font-medium">Agent deployment failure</div>
                      <div className="text-sm text-gray-600">TechFlow Agency • 5 min ago</div>
                    </div>
                    <Button size="sm">Take Over</Button>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                    <div>
                      <div className="font-medium">Billing inquiry</div>
                      <div className="text-sm text-gray-600">Digital Creators Hub • 12 min ago</div>
                    </div>
                    <Button size="sm">Take Over</Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full justify-start">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Force Agent Restart
                </Button>
                <Button className="w-full justify-start">
                  <Database className="h-4 w-4 mr-2" />
                  Clear Cache
                </Button>
                <Button className="w-full justify-start">
                  <Upload className="h-4 w-4 mr-2" />
                  Deploy Hotfix
                </Button>
                <Button className="w-full justify-start">
                  <Terminal className="h-4 w-4 mr-2" />
                  Access Server Console
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="billing">
          {/* Billing Management */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">$45,500</div>
                <p className="text-sm text-gray-600">This month</p>
                <div className="mt-4 space-y-2">
                  <div className="flex justify-between">
                    <span>Subscriptions</span>
                    <span>$38,200</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Setup Fees</span>
                    <span>$5,800</span>
                  </div>
                  <div className="flex justify-between">
                    <span>NFT Sales</span>
                    <span>$1,500</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Issues</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>Failed Payments</span>
                    <Badge variant="destructive">3</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Pending Refunds</span>
                    <Badge variant="secondary">1</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Disputed Charges</span>
                    <Badge variant="secondary">0</Badge>
                  </div>
                </div>
                <Button className="w-full mt-4">
                  <CreditCard className="h-4 w-4 mr-2" />
                  Manage Payments
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Token Economy</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Total HRMNY Supply</span>
                    <span>10M</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Circulating</span>
                    <span>2.5M</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Staked</span>
                    <span>1.2M</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Current Price</span>
                    <span>$0.45</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="system">
          {/* System Administration */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>System Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full justify-start">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Restart All Services
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Database className="h-4 w-4 mr-2" />
                  Database Maintenance
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  Export System Logs
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Upload className="h-4 w-4 mr-2" />
                  Deploy System Update
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Integration Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>GoHighLevel</span>
                    <Badge className="bg-green-500">Connected</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>HubSpot</span>
                    <Badge className="bg-green-500">Connected</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Salesforce</span>
                    <Badge variant="secondary">Maintenance</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Stripe</span>
                    <Badge className="bg-green-500">Connected</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>OpenAI</span>
                    <Badge className="bg-green-500">Connected</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="security">
          {/* Security Management */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Security Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Failed Login Attempts</span>
                    <Badge variant="secondary">12 (24h)</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Active Sessions</span>
                    <Badge className="bg-green-500">1,247</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Suspicious Activity</span>
                    <Badge variant="destructive">2</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>SSL Certificate</span>
                    <Badge className="bg-green-500">Valid</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Access Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full justify-start">
                  <Lock className="h-4 w-4 mr-2" />
                  Manage User Permissions
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Shield className="h-4 w-4 mr-2" />
                  Review Security Logs
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Block Suspicious IPs
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Rotate API Keys
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

