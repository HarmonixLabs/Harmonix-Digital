import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Search, 
  Grid3X3, 
  List, 
  Play, 
  Pause, 
  Settings, 
  FileText,
  TrendingUp,
  Fuel,
  MoreHorizontal
} from 'lucide-react'
import { LineChart, Line, ResponsiveContainer } from 'recharts'

const agents = [
  {
    id: 1,
    name: 'Sales Bot Alpha',
    status: 'active',
    tasksRun: 120,
    successRate: 95,
    roi: 120,
    fuel: 75,
    avatar: '🤖',
    performance: [
      { value: 10 }, { value: 15 }, { value: 25 }, { value: 30 }, { value: 35 }
    ]
  },
  {
    id: 2,
    name: 'Content Creator',
    status: 'idle',
    tasksRun: 85,
    successRate: 88,
    roi: 95,
    fuel: 45,
    avatar: '✍️',
    performance: [
      { value: 8 }, { value: 12 }, { value: 18 }, { value: 22 }, { value: 20 }
    ]
  },
  {
    id: 3,
    name: 'Data Analyzer',
    status: 'error',
    tasksRun: 200,
    successRate: 92,
    roi: 180,
    fuel: 20,
    avatar: '📊',
    performance: [
      { value: 15 }, { value: 20 }, { value: 25 }, { value: 18 }, { value: 15 }
    ]
  },
  {
    id: 4,
    name: 'Customer Support',
    status: 'active',
    tasksRun: 340,
    successRate: 97,
    roi: 250,
    fuel: 80,
    avatar: '💬',
    performance: [
      { value: 20 }, { value: 25 }, { value: 30 }, { value: 35 }, { value: 40 }
    ]
  }
]

export function MyAgents() {
  const [viewMode, setViewMode] = useState('grid')
  const [searchTerm, setSearchTerm] = useState('')

  const filteredAgents = agents.filter(agent =>
    agent.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-500'
      case 'idle': return 'bg-yellow-500'
      case 'error': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'active': return <Badge className="bg-green-100 text-green-800">Active</Badge>
      case 'idle': return <Badge className="bg-yellow-100 text-yellow-800">Idle</Badge>
      case 'error': return <Badge className="bg-red-100 text-red-800">Error</Badge>
      default: return <Badge>Unknown</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">My Agents</h1>
        <Button>
          <Play className="h-4 w-4 mr-2" />
          Deploy New Agent
        </Button>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Search agents..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Button variant="outline" size="sm">
            Bulk Actions
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('grid')}
          >
            <Grid3X3 className="h-4 w-4" />
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('list')}
          >
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Agent Grid */}
      <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
        {filteredAgents.map((agent) => (
          <Card key={agent.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="text-2xl">{agent.avatar}</div>
                  <div>
                    <CardTitle className="text-lg">{agent.name}</CardTitle>
                    <div className="flex items-center space-x-2 mt-1">
                      <div className={`w-2 h-2 rounded-full ${getStatusColor(agent.status)}`} />
                      {getStatusBadge(agent.status)}
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Key Metrics */}
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-lg font-bold">{agent.tasksRun}</div>
                  <div className="text-xs text-muted-foreground">Tasks Run</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-green-600">{agent.successRate}%</div>
                  <div className="text-xs text-muted-foreground">Success Rate</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-blue-600">${agent.roi}</div>
                  <div className="text-xs text-muted-foreground">ROI</div>
                </div>
              </div>

              {/* Fuel Meter */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium flex items-center">
                    <Fuel className="h-4 w-4 mr-1" />
                    Fuel
                  </span>
                  <span className="text-sm text-muted-foreground">{agent.fuel}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      agent.fuel > 50 ? 'bg-green-500' : 
                      agent.fuel > 20 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${agent.fuel}%` }}
                  />
                </div>
              </div>

              {/* Performance Chart */}
              <div className="h-16">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={agent.performance}>
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#6366f1" 
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-2">
                {agent.status === 'active' ? (
                  <Button size="sm" variant="outline" className="flex-1">
                    <Pause className="h-4 w-4 mr-1" />
                    Stop
                  </Button>
                ) : (
                  <Button size="sm" className="flex-1">
                    <Play className="h-4 w-4 mr-1" />
                    Start
                  </Button>
                )}
                <Button size="sm" variant="outline">
                  <Settings className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="outline">
                  <FileText className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

