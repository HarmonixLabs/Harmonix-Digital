import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Sidebar } from './components/Sidebar'
import { Header } from './components/Header'
import { Dashboard } from './components/Dashboard'
import { SuperAgencyDashboard } from './components/SuperAgencyDashboard'
import { MyAgents } from './components/MyAgents'
import { Marketplace } from './components/Marketplace'
import { CreatorZone } from './components/CreatorZone'
import { Wallet } from './components/Wallet'
import { Settings } from './components/Settings'
import { WhatIf } from './components/WhatIf'
import { MasterAdminDashboard } from './components/MasterAdminDashboard'
import './App.css'

function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  return (
    <Router>
      <div className="flex h-screen bg-gray-50">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header />
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-6">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/super-agency" element={<SuperAgencyDashboard />} />
              <Route path="/my-agents" element={<MyAgents />} />
              <Route path="/marketplace" element={<Marketplace />} />
              <Route path="/creator-zone" element={<CreatorZone />} />
              <Route path="/wallet" element={<Wallet />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/what-if" element={<WhatIf />} />
              <Route path="/master-admin" element={<MasterAdminDashboard />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  )
}

export default App

